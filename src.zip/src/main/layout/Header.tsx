import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import Button from "../utils/forms/Button";

const Header = (props: Readonly<any>) => {
    const location = useLocation();
    
    const [value, setValue] = React.useState<string>("");
    const [isSearch, setIsSearch] = React.useState<boolean>(false);

    const onSearch = (target: EventTarget) => {
        const t = target as HTMLInputElement
        setValue(t.value);
    }

    React.useEffect(() => {
        if(location.pathname === "/") {
            // props.setProducts(value)
        }
        if((location.pathname === "/" || location.pathname !== "/") && isSearch) {
            console.log(value);
            setIsSearch(false);
        }
    }, [isSearch, value, location.pathname]) 

    return (
        <div className="header">
            <h1 className="title">Королевство Роз Волгоград</h1>
            <div className="links">
                <NavLink to="/">Главная</NavLink>
                <NavLink to="/contact">Связаться с нами</NavLink>
                <NavLink to={`/${props.catalogueSeason}`}>
                    Каталог на {props.season}
                </NavLink>
                <NavLink to="/cart">Корзина <span>{props.countRef}</span></NavLink>
            </div>
            <div className="search">
                <div className="searchInput">
                    <input
                        onChange={(event: React.ChangeEvent<HTMLInputElement>): void => onSearch(event.target)}
                        placeholder="Искать"    
                    />
                </div>
                <Button cb={() => setIsSearch(true)} value={"Искать"} isDisabled={value !== "" ? false : true}/>
            </div>
        </div>
    )
}

export default Header;