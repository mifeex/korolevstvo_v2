import React from "react";
import s from "./style.module.css";

interface ButtonType {
    isDisabled: boolean;
    value: string;
    cb?: () => void;
    className?: string;
}

const Button = (props: Readonly<ButtonType>) => {
    const clickHandler = (target: EventTarget): void => {
        const t = target as HTMLInputElement;

        t.classList.add(`${s.buttonActive}`);

        setTimeout(() => {
            t.classList.remove(`${s.buttonActive}`);
        }, 300);

        props.cb !== undefined && props.cb();
    }

    return (
        <>
            <button
                className={`${s.button} ${props.className !== undefined && props.className}`}
                onClick={(e: React.MouseEvent) => clickHandler(e.target)}
                disabled={props.isDisabled}
            >{props.value}</button>
        </>
    )
}

export default Button;