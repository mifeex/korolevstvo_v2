import React from "react";
import s from "./style.module.css";

const Input = (props: Readonly<any>) => {
    const [isAgreed, setAgreed] = React.useState<boolean>(false);
    const [formatRef, setFormat] = React.useState<string>("");

    const setExam = (value: string) => {
        switch(value) {
            case "Email":
                setFormat("name@mail.domain");
                return /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            case "Номер телефона":
                setFormat("+7 999 000 11 11");
                return /^((8|\+7)[\- ]?)?(\(?\d{3}\)?[\- ]?)?[\d\- ]{10}$/;
            case "Индекс":
                setFormat("123456");
                return /^([0-9]{6})$/;
            case "Номер дома": case"Квартира":
                setFormat("1 или 1(литера)");
                return /^[0-9а-яА-ЯЁё]$/;
            default:
                setFormat("ФИО/Область/Город");
                return /^([а-яА-ЯЁё]{2,20})$/;
        }
    }

    const checkAgreed = (value: string) => {
        // console.log(formatRef)
        if(value.match(setExam(props.name))) {
            setAgreed(true);
            props.setRegExpState()
        }
        else setAgreed(false);
    }

    return (
        <div className={s.inputContainer}>
            {(!isAgreed && formatRef !== "") && <div className={s.errorContainer}>
                Введите {props.name} в формате {formatRef}
            </div>}
            <input
                type="text"
                onChange={(e: React.ChangeEvent<HTMLInputElement>):void => checkAgreed(e.target.value)}
                placeholder={props.name}
                className={`${s.input} ${(!isAgreed && formatRef !== "") && s.inputError}`}
            />
        </div>
    )
}

export default Input;