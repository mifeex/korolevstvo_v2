import React, { ReactElement } from "react";
import ReactDOM from "react-dom";
import Input from "../forms/Input";
import Button from "../forms/Button";
import s from "./style.module.css";

const initialState = {
    inputs: [{
        name: "",
        value: "",
        regExp: false,
    }],
    isAllTrue: false,
}

const inputName = [
    "Фамилия", "Имя", "Отчество", "Email", "Номер телефона",
    "Область", "Населенный пункт", "Номер дома",
    "Квартира", "Индекс"
]

type PortalStateType = typeof initialState;
type InputsType = typeof initialState.inputs[0];
type ActionType = {
    type: string;
    data: number | Array<InputsType> | any;
}
type PropsType = {
    openModalHandler: (value: boolean) => boolean | void;
}

const reducer = (state: PortalStateType | any, action: ActionType) => {
    const _completeExam = (newState: PortalStateType) => {
        let count = 0;

        for(let i in newState.inputs) {
            newState.inputs[i].regExp && count++;
        }

        if(count === 10) return newState.isAllTrue = true;
    }

    switch(action.type) {
        case "FILL_STATE": {
            return {inputs: action.data}
        }
        case "COMPLETE": {
            const newState = {...state};
            newState.inputs[action.data].regExp = true;
            _completeExam(newState);

            return newState;
        }

        default: {
            break;
        }
    } 
}

const CartPortal = (props: Readonly<PropsType>) => {
    const [state, dispatch] = React.useReducer(reducer, initialState);
    const [isAgreed, setAgreed] = React.useState<boolean>(false);

    React.useEffect(() => {
        dispatch({
            type: "FILL_STATE",
            data: inputName.map((e: string) => ({name: e, value: "", regExp: false,}))
        })
    }, [inputName]);
    
    const clickHandler = (target: EventTarget): void => {
        const t = target as HTMLInputElement;
        if(t.classList.value.includes("cartModalContainer")) props.openModalHandler(false);
    }

    return ReactDOM.createPortal(
        <div className={s.cartModalContainer} onClick={(e: React.MouseEvent<HTMLInputElement>) => clickHandler(e.target)}>
            <button className={s.close} onClick={():void | boolean => props.openModalHandler(false)}>X</button>
            <div className={s.cartModal}>
                <h3 className={s.header}>Оформить заказ</h3>
                {state !== undefined && state.inputs.map((e: InputsType, id: number):ReactElement<any, any> => (
                    <Input
                        key={id}
                        name={e.name}
                        setRegExpState={() => dispatch({type: "COMPLETE", data: id})}
                    />
                ))}
                <p className={s.agreed} onClick={():void => setAgreed(!isAgreed)}>
                    <input className={s.checkBox} type={"checkbox"} checked={isAgreed} />
                    Я согласен(на) на обработку персональных данных
                </p>
                <Button
                    value={"Отправить"}
                    isDisabled={!(isAgreed && state.isAllTrue)}
                />
            </div>
        </div>
    , document.body)
}

export default CartPortal;
