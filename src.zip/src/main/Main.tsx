import React from "react";
import {BrowserRouter, Routes, Route} from "react-router-dom"
import Header from "./layout/Header";
import Catalogue from "./components/catalogue/Catalogue";
import Cart from "./components/cart/Cart";
import Product from "./components/product/Product";
import { CartValueType } from "./components/catalogue/catalogue-components/ProductCard";
import SearchByKeys from "./components/catalogue/catalogue-components/SearchByKeys";
import useMainRequest from "./components/hooks/useMainRequest";

const initialState = {
    id: 0,
    name: "Akari",
    type: "Роза Японские сорта",
    group: "Флорибунды",
    height: "80-95",
    cost: 1900,
    src: "public/images/0000086_1.jpg"
}

const state2 = {...initialState, name: "Rps", id: 5, cost: 1500}

export type stateType = typeof initialState;

const Main = () => {
    const [cartId, setCartID] = React.useState<string[]>([]);
    const [cart, setCart] = React.useState<CartValueType[]>([]);
    const [products, setProducts] = React.useState<stateType[]>([]);
    const [count, setCount] = React.useState<number>(0);
    // создаем массив объектов в который кладем название сорта как ключ и props. Для ls - ключ keys. Помещаем при рендере в useState
    React.useEffect(() => {
        console.log(cartId, cart)
        if(cartId.length > 0 && cart.length > 0) {
            localStorage.setItem("cartKeys", JSON.stringify(cartId));
            localStorage.setItem(`cartValue`, JSON.stringify(cart));
        }
        
        const calcCount = () => {
            let interimCount = 0;

            cart.map((e:CartValueType) => {
                interimCount += e.count;
            })

            setCount(interimCount);
        }

        calcCount();
    }, [cartId, cart])

    const setCartIDHandler = (value: Array<string>) => {
        setCartID(value);
    }

    const setCartHandler = (value: Array<CartValueType>) => {
        setCart(value)
    }

    React.useEffect(() => {
        const cartKeyLS = localStorage.getItem("cartKeys");
        const cartValueLS = localStorage.getItem(`cartValue`);

        setCartID(cartKeyLS !== null ? JSON.parse(cartKeyLS) : []);
        setCart(cartValueLS!== null ? JSON.parse(cartValueLS) : []);
    }, [])

    useMainRequest(setProducts);

    console.log(products)

    return (
        <>
            <BrowserRouter>
                <Header
                    countRef={count}
                    setProducts={setProducts}
                />
                <SearchByKeys />
                <Routes>
                    <Route
                        path="/"
                        element={<Catalogue
                            cartId={cartId}
                            setCartID={setCartIDHandler}
                            cart={cart}
                            setCart={setCartHandler}
                            products={products}
                        />}
                    />
                    <Route
                        path={`/product/:productId`}
                        element={<Product
                            cartId={cartId}
                            setCartID={setCartIDHandler}
                            cart={cart}
                            setCart={setCartHandler}
                        />}
                    />
                    <Route
                        path="/cart"
                        element={<Cart
                            cartId={cartId}
                            setCartID={setCartIDHandler}
                            cart={cart}
                            setCart={setCartHandler}
                        />}
                    />
                </Routes>
            </BrowserRouter>
        </>
    )
}

export default Main;