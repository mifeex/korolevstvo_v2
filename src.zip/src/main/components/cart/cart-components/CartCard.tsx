import React from "react";
import { NavLink } from "react-router-dom";
import Button from "src/main/utils/forms/Button";
import {addToCart, CartValueType} from "../../catalogue/catalogue-components/ProductCard";
import s from "../style.module.css";

export type CartPropsType = {
    id?: string | any;
    cartId: Array<string>;
    setCartID: (value: Array<string>) => Array<string> | void;
    cart: Array<CartValueType>;
    setCart: (value: Array<CartValueType>) => Array<CartValueType> | void;
}

type CartPropsTypeWithClean = CartPropsType & {
    isClean: boolean;
}

const CartCard = (props: Readonly<CartPropsTypeWithClean>) => {
    React.useEffect(() => {
        if((props.cart[id].count < 1 && props.cartId.length === 1) || props.isClean) {
            localStorage.removeItem("cartKeys");
            localStorage.removeItem(`cartValue`);
            props.setCartID([]);
            props.setCart([]);
        }
    }, [props])

    const id = props.cart.findIndex((e: CartValueType, k: number): number | boolean => {
        return e[props.id] !== undefined && e[props.id].name === props.id;
    });

    const cartValue = props.cart[id];

    const removeOne = (): void => {
        const newCart = [...props.cart];

        if(props.cart[id].count >= 1) newCart[id].count -= 1;

        if(props.cart[id].count < 1 && props.cartId.length > 1) {
            const newCartId = props.cartId.filter((e: any) => e !== props.id);
            console.log(newCartId)

            newCart.splice(id, 1);
            props.setCartID(newCartId);
        }

        props.setCart(newCart);
    }

    const removeAll = () => {

    }

    return (
        <>
            <div className={s.cart}>
                <div className={s.cartImage}>
                    <img src={cartValue[props.id].src} />
                </div>
                <div className={s.cartName}>
                    <span><NavLink to={`/product/${cartValue[props.id].id}`}>Сорт: {cartValue[props.id].name}</NavLink></span>
                </div>
                <div className={s.cartStats}>
                    <span>Количество: {cartValue.count}шт</span>
                    <span>Стоимость: {cartValue.count * cartValue[props.id].cost} руб</span>
                </div>
                <div className={s.changeCart}>
                    <Button isDisabled={false} value="Добавить" className={s.add} cb={() => addToCart({...props, product: {...cartValue[props.id]}})}/>
                    <Button isDisabled={false} value="Удалить" className={s.remove} cb={() => removeOne()}/>
                </div>
                
            </div>
            
        </>
    )
}

export default CartCard;