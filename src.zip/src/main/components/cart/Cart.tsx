import React from "react";
import CartCard, { CartPropsType } from "./cart-components/CartCard";
import CartPortal from "src/main/utils/modals/CartPortal";
import s from "./style.module.css";
import Button from "src/main/utils/forms/Button";

const Cart = (props: CartPropsType) => {
    const [openModal, openModalHandler] = React.useState<boolean>(false);
    const [isClean, isCleanHandler] = React.useState<boolean>(false);

    return (
        <div className={s.cartContainer}>
            {props.cartId.map((e: string) => {
                return <CartCard
                    id={e}
                    key={e}
                    isClean={isClean}
                    cartId={props.cartId}
                    setCartID={props.setCartID}
                    cart={props.cart}
                    setCart={props.setCart}
                />
            })}
            {openModal && <CartPortal openModalHandler={openModalHandler} />}
            <Button value="Удалить все" className={s.removeAll} cb={() => isCleanHandler(!isClean)} isDisabled={false} />
            <Button value="Подтвердить и перейти к заказу" cb={():void => openModalHandler(true)} isDisabled={false} />
        </div>
    )
}

export default Cart;