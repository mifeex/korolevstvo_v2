import React, { Dispatch, SetStateAction } from "react";
import axios from "axios";
import { stateType } from "src/main/Main";

const useMainRequest = (set: Dispatch<SetStateAction<stateType[]>>) => {
    React.useEffect(() => {
        axios.get("https://localhost:8000/")
        .then((res: any) => {
            return res
        })
        .then((e) => {
            set((cart: stateType | any) => {
                return [...cart, ...e.data.param.map((e: any) => ({
                    id: e.id,
                    name: e.sort,
                    type: e.brand,
                    group: e.rose_type,
                    height: e.heigh,
                    cost: e.cost,
                    src: `public/images/00000${e.id}_1.jpg`
                }))]
            })
        })
    }, [])
}

export default useMainRequest;