import React, { SetStateAction } from "react";
import SearchByKeys from "./catalogue-components/SearchByKeys";
import ProductCard, { CartValueType } from "./catalogue-components/ProductCard"
import { stateType } from "src/main/Main";

interface CataloguePropsType {
    cartId: Array<string>;
    setCartID: (value: Array<string>) => Array<string> | void;
    cart: Array<CartValueType>;
    setCart: (value: Array<CartValueType>) => Array<CartValueType> | void;
    products: Array<stateType>;
}

const Catalogue = (props: CataloguePropsType) => {
    return (
        <div className="catalogue">
            <div className="catalogueCardsArea">
                {props.products.map((e: stateType) => {
                    return <ProductCard
                        key={Math.random()}
                        product={e}
                        cartId={props.cartId}
                        cart={props.cart}
                        setCartID={props.setCartID}
                        setCart={props.setCart}
                    />
                })}
            </div>
        </div>
    )
}

export default Catalogue;