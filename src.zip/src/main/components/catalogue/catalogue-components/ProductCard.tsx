import React from "react";
import { NavLink } from "react-router-dom";
import s from "../style.module.css";
import type {stateType} from "../../../Main";

interface Api {
    [name: string]: stateType;  
}

export type CartValueType = Api & {
    count: number;
}

interface propsType {
    product: stateType;
    cartId: Array<string>;
    setCartID: (value: Array<string> | any) => Array<string> | void;
    cart: Array<CartValueType>;
    setCart: (value: Array<CartValueType> | any) => Array<CartValueType> | void;
}

export const addToCart = (props: propsType): void => {
    const toCard = {
        [props.product.name]: {
            name: props.product.name,
            type: props.product.type,
            group: props.product.group,
            height: props.product.height,
            cost: props.product.cost,
            src: props.product.src,
            id: props.product.id,
        },
        count: 1
    } as CartValueType;

    if(props.cartId.includes(props.product.name)) {
        const id = props.cart.findIndex((e:CartValueType) => {
            return e[props.product.name]?.name === props.product.name
        });
        
        const newCart = [...props.cart];
        newCart[id].count += 1;

        props.setCart(newCart);
    }
    else {
        props.setCartID((e: Array<string>) => [...e, props.product.name])
        props.setCart((e: Array<CartValueType>) => [...e, toCard] as Array<CartValueType>)
    }
}

const ProductCard = (props: Readonly<propsType>) => {
    return (
        <div className="catalogueCard">
            <h3>{props.product.name}</h3>
            <img src={props.product.src} />
            <p>{props.product.type}</p>
            <p>{props.product.group}</p>
            <p>{props.product.height}</p>
            <p>{props.product.cost}</p>
            <div className={s.product}>
                <NavLink to={`/product/${props.product.id}`}>Подробнее</NavLink>
                <a onClick={() => addToCart(props)} className={s.addToCart}>Добавить в корзину</a>
            </div>
        </div>
    )
}

export default ProductCard;