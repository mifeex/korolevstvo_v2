import React from "react";
import s from "../style.module.css";

const SearchByKeys = (props: any) => {
    return (
        <div className={s.search}>
            Search
        </div>
    )
}

export default SearchByKeys;