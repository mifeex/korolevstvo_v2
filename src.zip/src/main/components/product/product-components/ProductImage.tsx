import React from "react";
import { ImageStoreType } from "../Product";
import s from "../style.module.css"

interface ImageProps {
    ChangeImageStore: (value: EventTarget) => ImageStoreType | void;
    name: string;
    src: string;
}

const ProductImage = (props: Readonly<ImageProps>) => {
    const [isHidden, isHiddenHandler] = React.useState<boolean>(false);

    return (
        <>
            {!isHidden && <div
                className={s.ProductImageStyle}
                onClick={(e: React.MouseEvent<HTMLDivElement>) => props.ChangeImageStore(e.target)}
            >
                <img
                    src={props.src}
                    alt={props.name + " 1"}
                    onError={() => isHiddenHandler(true)}
                />
            </div>}
        </>
    )
}

export default ProductImage