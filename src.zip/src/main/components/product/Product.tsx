import React from "react";
import Button from "src/main/utils/forms/Button";
import { CartPropsType } from "../cart/cart-components/CartCard";
import { addToCart } from "../catalogue/catalogue-components/ProductCard";
import ProductImage from "./product-components/ProductImage";
import s from "./style.module.css"

const initialState = {
    id: 0,
    name: "Akari",
    type: "Роза Японские сорта",
    group: "Флорибунды",
    height: "80-95",
    form: "Чаша",
    color: "Молочный",
    cost: 1900,
    src: ["http://korolevstvo-rose.ru/images/0000086_3.jpg", "http://korolevstvo-rose.ru/images/0000086_1.jpg", "http://korolevstvo-rose.ru/images/0000086_2.jpg", "80.jpg", "1.jpg"],
    description: "Роза из серии Generosa. Прямостоячий куст с темной листвой, с многочисленными махровыми шаровидными цветами, собранными в соцветия, которые появляются на протяжении всего сезона.Окраска цветов - розовая (rose clair), аромат умеренный. Посадка - на солнце. Роза названа в честь известного французского шеф-повара, обладательницы 3-х звезд Мишлен Ан-Софи Пик."
}

export type ImageStoreType = {
    main: string;
    clicked: string;
}

const Product = (props: Readonly<CartPropsType>) => {
    const [getProduct, getProductHandler] = React.useState<any>(initialState);
    const [setImage, setImageHandler] = React.useState<string>(getProduct.src[0])

    const ChangeImageStore = (target: EventTarget) => {
        const t = target as HTMLImageElement;
        const t2 = t?.children[0] as HTMLImageElement
        const src = t.src;

        t2 !== undefined ? setImageHandler(t2.src) : setImageHandler(src); 
    }

    return (
        <div className={s.product}>
            <div className={s.imagesContainer}>
                <div className={s.mainImage}>
                    <img src={setImage} alt={getProduct.name} />
                </div>
                <div className={s.stats}>
                    <h3>{getProduct.name}</h3>
                    <table>
                        <tbody>
                        <tr>
                                <th>Производитель</th>
                                <td>{getProduct.type}</td>
                            </tr>
                            <tr>
                                <th>Цвет</th>
                                <td>{getProduct.color}</td>
                            </tr>
                            <tr>
                                <th>Группа</th>
                                <td>{getProduct.group}</td>
                            </tr>
                            <tr>
                                <th>Высота</th>
                                <td>{getProduct.height}</td>
                            </tr>
                            <tr>
                                <th>Форма цветка</th>
                                <td>{getProduct.form}</td>
                            </tr>
                        </tbody>
                    </table>
                    <div className={s.addToCart}>
                        <div className={s.cost}>Стоимость: {getProduct.cost}</div>
                        <Button
                            isDisabled={false}
                            value={"Добавить в корзину"}
                            cb={() => addToCart({...props, product: {...getProduct}})}
                        />                    
                    </div>
                </div>
            </div>
            <div className={s.imagesList}>
                {getProduct.src.map((s: string) => {
                    return <ProductImage
                        ChangeImageStore={ChangeImageStore}
                        name={getProduct.name}
                        key={s} //id
                        src={s}
                    />
                })}
            </div>
            <div className={s.description}>{getProduct.description}</div>

        </div>
    )
}

export default Product;