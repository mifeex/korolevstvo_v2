import React from "react";
import Main from "./main/Main";

function App() {
    return (
        <div className="App">
            <Main />
        </div>
    );
}

export default App;
